falcon_template = """
Answer the question as truthfully as possible, and if the answer is not contained within the file,
say "I don't know."
context: {context}
question: {question}
answer: 
"""